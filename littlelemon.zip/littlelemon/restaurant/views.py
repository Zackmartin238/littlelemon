from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse

from .models import Menu

def menu(request):
    # Retrieve all menu items from the database
    menu_data = Menu.objects.all()
    
    # Create a dictionary containing the menu data
    main_data = {
        'menu': menu_data
    }
    
    # Render the menu page template with the menu data
    return render(request, 'menu.html', main_data)

from django.shortcuts import render

def home(request):
    return render(request, 'base.html')

def about(request):
    return HttpResponse("")
    
def book(request):
    return HttpResponse("")
    

def display_menu_items(request, pk=None):
    menu_item = None
    
    if pk:
        menu_item = get_object_or_404(Menu, pk=pk)
    
    context = {
        'menu_item': menu_item
    }
    
    return render(request, 'menu_item.html', context)